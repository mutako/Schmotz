
package com.schmotz.calendar

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun AuthGate(onAuthenticated: () -> Unit) {
    val auth = Firebase.auth
    val scope = rememberCoroutineScope()

    var isRegister by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(auth.currentUser) {
        if (auth.currentUser != null) onAuthenticated()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Schmotz Calender", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        if (isRegister) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Account name") }, singleLine = true)
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Access code (shared)") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { isRegister = !isRegister }) {
                Text(if (isRegister) "Have an account? Sign in" else "Create account")
            }
            Button(onClick = {
                scope.launch {
                    try {
                        if (isRegister) {
                            val res = auth.createUserWithEmailAndPassword(email, pass).await()
                            val profile = UserProfile(
                                uid = res.user!!.uid,
                                email = email,
                                displayName = if (name.isBlank()) email.substringBefore("@") else name,
                                householdCode = if (code.isBlank()) "FAMILY" else code
                            )
                            saveProfile(profile)
                            onAuthenticated()
                        } else {
                            auth.signInWithEmailAndPassword(email, pass).await()
                            onAuthenticated()
                        }
                    } catch (e: Exception) {
                        error = e.message
                    }
                }
            }) { Text(if (isRegister) "Register & Continue" else "Sign in") }
        }
    }
}
