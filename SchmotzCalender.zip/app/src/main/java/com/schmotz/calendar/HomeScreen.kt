
package com.schmotz.calendar

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

enum class Tab { Calendar, Links, Upcoming, Search }

@Composable
fun HomeScreen(onSignOut: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.Calendar) }
    var profile by remember { mutableStateOf<UserProfile?>(null) }

    LaunchedEffect(Unit) {
        profile = loadProfile()
    }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Schmotz Calender") },
                actions = {
                    TextButton(onClick = { /* navigate settings */ }) { Text("Settings") }
                    TextButton(onClick = {
                        Firebase.auth.signOut()
                        onSignOut()
                    }) { Text("Sign out") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab==Tab.Calendar, onClick={tab=Tab.Calendar}, label={Text("Month")}, icon={})
                NavigationBarItem(selected = tab==Tab.Upcoming, onClick={tab=Tab.Upcoming}, label={Text("Upcoming")}, icon={})
                NavigationBarItem(selected = tab==Tab.Search, onClick={tab=Tab.Search}, label={Text("Search")}, icon={})
                NavigationBarItem(selected = tab==Tab.Links, onClick={tab=Tab.Links}, label={Text("Links")}, icon={})
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                Tab.Calendar -> CalendarMonthView(profile)
                Tab.Upcoming -> UpcomingList(profile)
                Tab.Search -> SearchView(profile)
                Tab.Links -> LinksView(profile)
            }
        }
    }
}
