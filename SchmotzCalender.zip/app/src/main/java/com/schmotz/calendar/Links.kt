
package com.schmotz.calendar

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.tasks.await
import org.jsoup.Jsoup

@Composable
fun LinksView(profile: UserProfile?) {
    var links by remember { mutableStateOf<List<SharedLink>>(emptyList()) }
    var category by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(profile) {
        profile ?: return@LaunchedEffect
        val snap = linksCollection(profile.householdCode).orderBy("sharedAt").get().await()
        links = snap.documents.mapNotNull { it.toObject(SharedLink::class.java)?.copy(id = it.id) }.reversed()
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Filter by category") })
            Button(onClick = {
                info = if (category.isBlank()) null else "Showing only: $category"
            }) { Text("Apply") }
        }
        info?.let { Text(it, style = MaterialTheme.typography.labelMedium) }
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(links.filter { category.isBlank() || it.category.equals(category, true) }) { link ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        if (link.imageUrl.isNotBlank()) {
                            AsyncImage(model = link.imageUrl, contentDescription = null, modifier = Modifier.fillMaxWidth().height(180.dp))
                        }
                        Text(link.title.ifBlank { link.url }, style = MaterialTheme.typography.titleMedium)
                        Text(link.description, style = MaterialTheme.typography.bodySmall)
                        Text("By ${link.sharedByName} on ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm").format(java.util.Date(link.sharedAt))}",
                            style = MaterialTheme.typography.labelSmall)
                        TextButton(onClick = {
                            // open link
                            // (In Compose preview skip)
                        }) { Text("Open") }
                    }
                }
            }
        }
    }
}

suspend fun fetchMetadata(url: String): Triple<String,String,String> {
    return try {
        val doc = Jsoup.connect(url).get()
        val title = doc.select("meta[property=og:title]").attr("content").ifBlank { doc.title() }
        val desc = doc.select("meta[property=og:description]").attr("content")
        val image = doc.select("meta[property=og:image]").attr("content")
        Triple(title, desc, image)
    } catch (e: Exception) {
        Triple(url, "", "")
    }
}
