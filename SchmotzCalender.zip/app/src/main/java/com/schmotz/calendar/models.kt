
package com.schmotz.calendar

data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val householdCode: String = "" // shared access code
)

data class Event(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val start: Long = 0L,
    val end: Long = 0L,
    val createdByUid: String = "",
    val createdByName: String = "",
    val createdAt: Long = 0L
)

data class SharedLink(
    val id: String = "",
    val url: String = "",
    val title: String = "",
    val description: String = "",
    val imageUrl: String = "",
    val category: String = "",
    val sharedByUid: String = "",
    val sharedByName: String = "",
    val sharedAt: Long = 0L
)
