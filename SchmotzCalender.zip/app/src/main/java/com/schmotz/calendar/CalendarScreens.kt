
package com.schmotz.calendar

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.kizitonwose.calendar.compose.Calendar
import com.kizitonwose.calendar.core.*
import kotlinx.coroutines.tasks.await
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.WeekFields
import java.util.*

@Composable
fun CalendarMonthView(profile: UserProfile?) {
    var events by remember { mutableStateOf<List<Event>>(emptyList()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    val currentMonth = remember { YearMonth.now() }
    val startMonth = remember { currentMonth.minusMonths(24) }
    val endMonth = remember { currentMonth.plusMonths(24) }
    val daysOfWeek = remember { daysOfWeek(WeekFields.of(Locale.getDefault()).firstDayOfWeek) }

    LaunchedEffect(profile) {
        profile ?: return@LaunchedEffect
        val snap = eventsCollection(profile.householdCode).get().await()
        events = snap.documents.mapNotNull { it.toObject(Event::class.java)?.copy(id = it.id) }
    }

    Column(Modifier.fillMaxSize()) {
        Calendar(
            startMonth = startMonth,
            endMonth = endMonth,
            firstDayOfWeek = daysOfWeek.first(),
            monthHeader = { month ->
                Text("${month.yearMonth}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(12.dp))
            },
            dayContent = { day ->
                val hasEvent = events.any { e ->
                    val d = java.time.Instant.ofEpochMilli(e.start).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                    d == day.date
                }
                Text(
                    text = day.date.dayOfMonth.toString() + if (hasEvent) " •" else "",
                    modifier = Modifier
                        .padding(8.dp)
                        .clickable { selectedDate = day.date }
                )
            }
        )
        Spacer(Modifier.height(8.dp))
        val dayEvents = events.filter { e ->
            val d = java.time.Instant.ofEpochMilli(e.start).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
            d == selectedDate
        }
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { /* TODO: open editor */ }) { Text("Add event") }
        }
        LazyColumn {
            items(dayEvents) { ev ->
                ListItem(
                    headlineContent = { Text(ev.title) },
                    supportingContent = { Text(ev.description) },
                    trailingContent = { Text(java.text.SimpleDateFormat("HH:mm").format(java.util.Date(ev.start))) }
                )
                Divider()
            }
        }
    }
}

@Composable
fun UpcomingList(profile: UserProfile?) {
    var events by remember { mutableStateOf<List<Event>>(emptyList()) }
    LaunchedEffect(profile) {
        profile ?: return@LaunchedEffect
        val snap = eventsCollection(profile.householdCode).orderBy("start").limit(50).get().await()
        events = snap.documents.mapNotNull { it.toObject(Event::class.java)?.copy(id = it.id) }
    }
    LazyColumn {
        items(events) { ev ->
            ListItem(headlineContent = { Text(ev.title) },
                supportingContent = { Text(ev.description) },
                trailingContent = { Text(java.text.SimpleDateFormat("dd.MM HH:mm").format(java.util.Date(ev.start))) }
            )
            Divider()
        }
    }
}

@Composable
fun SearchView(profile: UserProfile?) {
    var q by remember { mutableStateOf("") }
    var events by remember { mutableStateOf<List<Event>>(emptyList()) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Search events") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (profile != null) {
                eventsCollection(profile.householdCode)
                    .whereGreaterThan("start", 0)
                    .get().addOnSuccessListener { snap ->
                        val all = snap.documents.mapNotNull { it.toObject(Event::class.java)?.copy(id = it.id) }
                        val filtered = all.filter { it.title.contains(q, true) || it.description.contains(q, true) || it.createdByName.contains(q, true) }
                        events = filtered
                    }
            }
        }) { Text("Search") }
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(events) { ev ->
                ListItem(headlineContent = { Text(ev.title) },
                    supportingContent = { Text(ev.description) },
                    trailingContent = { Text(java.text.SimpleDateFormat("dd.MM HH:mm").format(java.util.Date(ev.start))) }
                )
                Divider()
            }
        }
    }
}
